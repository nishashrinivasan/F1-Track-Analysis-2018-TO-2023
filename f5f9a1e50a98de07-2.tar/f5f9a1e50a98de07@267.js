function _1(htl){return(
htl.html`<h1>F1 Track Analysis 2018 TO 2023</h1>`
)}

function _f1Weather202320181(__query,FileAttachment,invalidation){return(
__query(FileAttachment("F1 Weather(2023-2018).csv"),{from:{table:"F1 Weather(2023-2018)"},sort:[],slice:{to:null,from:null},filter:[],select:{columns:null}},invalidation)
)}

function _3(Inputs,f1Weather202320181){return(
Inputs.table(f1Weather202320181)
)}

function _4(Plot,f1Weather202320181,d3){return(
Plot.plot({
  width: 900,
  height: 600,
  marginLeft: 80,
  marginBottom: 50,
  grid: true,
  x: {
    label: "Air Temperature (°C)",
    nice: true
  },
  y: {
    domain: [2018, 2019, 2020, 2021, 2022, 2023],
    label: "Season",
    labelOffset: 45,
    tickSize: 0
  },
  color: {
    scheme: "Plasma",
    label: "Track Temperature (°C)",
    legend: true
  },
  marks: [

    Plot.dot(f1Weather202320181, {
      x: "AirTemp",
      y: "Year",
      fill: "TrackTemp",
      r: 4,
      opacity: 0.6,
      title: d => `Race: ${d.Race}\nAir: ${d.AirTemp}°C\nTrack: ${d.TrackTemp}°C\nHumidity: ${d.Humidity}%`
    }),

    Plot.boxX(f1Weather202320181, {
      x: "AirTemp",
      y: "Year",
      fill: "TrackTemp",
      sort: { y: "x" },
      stroke: "black",
      strokeWidth: 0.8,
      fillOpacity: 0.4
    }),

    Plot.ruleX(
      d3.rollups(
        f1Weather202320181,
        v => d3.median(v, d => d.AirTemp),
        d => d.Year
      ).map(([Year, median]) => ({ Year, median })),
      { x: "median", stroke: "black", strokeDasharray: "4 2" }
    )
  ]
})
)}

function _5(htl){return(
htl.html`<h2>Track Temperature Vs Humidity</h2>`
)}

function _6(Plot,d3,f1Weather202320181){return(
Plot.plot({
  width: 900,
  height: 1200,
  marginBottom: 40,
  x: {
    label: "Track Temperature (°C)",
    grid: true
  },
  y: {
    label: "Humidity (%)",
    grid: true,
    marginRight: 40,
    marginLeft: 100,
    labelOffset: 45
    
  },
  color: {
    scheme: "Plasma",
    label: "Air Temperature (°C)",
    legend: true
  },
  marks: [
    Plot.cell(
      d3.rollups(
        f1Weather202320181,
        v => d3.mean(v, d => d.AirTemp),
        d => Math.round(d.TrackTemp),
        d => Math.round(d.Humidity)
      ).flatMap(([TrackTemp, humidityGroups]) =>
        humidityGroups.map(([Humidity, AirTemp]) => ({
          TrackTemp: +TrackTemp,
          Humidity: +Humidity,
          AirTemp
        }))
      ),
      { x: "TrackTemp", y: "Humidity", fill: "AirTemp" }
    ),
    Plot.ruleY([d3.mean(f1Weather202320181, d => d.Humidity)], {
      stroke: "black",
      strokeDasharray: "4 5",
      title: "Average Humidity"
    }),
    Plot.text(
      [{ y: d3.mean(f1Weather202320181, d => d.Humidity), label: "Avg Humidity" }],
      { y: "y", text: "label", dy: -6, fill: "black", textAnchor: "end" }
    )
  ]
})
)}

function _fields(){return(
["AirTemp", "Humidity", "Pressure", "Rainfall", "TrackTemp", "WindSpeed"]
)}

function _corr(d3){return(
function corr(x, y) {
  const n = x.length;
  if (y.length !== n) throw new Error("Columns must have same length");
  const x_ = d3.mean(x);
  const y_ = d3.mean(y);
  const XY = d3.sum(x, (_, i) => (x[i] - x_) * (y[i] - y_));
  const XX = d3.sum(x, (d) => (d - x_) ** 2);
  const YY = d3.sum(y, (d) => (d - y_) ** 2);
  return XY / Math.sqrt(XX * YY);
}
)}

function _correlations(d3,fields,corr,Plot,f1Weather202320181){return(
d3.cross(fields, fields).map(([a, b]) => ({
  a,
  b,
  correlation: corr(Plot.valueof(f1Weather202320181, a), Plot.valueof(f1Weather202320181, b))
}))
)}

function _10(htl){return(
htl.html`<h2>Factors affecting the track and performance</h2>`
)}

function _11(Plot,correlations){return(
Plot.plot({
  width: 500,
  height: 450,
  marginLeft: 100,
  color: { scheme: "PuRd", pivot: 0, legend: true, label: "correlation" },
  marks: [
    Plot.cell(correlations, { x: "a", y: "b", fill: "correlation" }),
    Plot.text(correlations, {
      x: "a",
      y: "b",
      text: (d) => d.correlation.toFixed(2),
      fill: (d) => (Math.abs(d.correlation) > 0.6 ? "white" : "black")
    })
  ]
})
)}

function _12(htl){return(
htl.html`<h2></h2>`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["F1 Weather(2023-2018).csv", {url: new URL("./files/543de0caee8672760bdd34339a876579e928c8e3a911b94bc508feace50de05906476cb290ff8d3464b62ad3b247b105bfdc46c1fbb3b5990470c65ba241932d.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["htl"], _1);
  main.variable(observer("f1Weather202320181")).define("f1Weather202320181", ["__query","FileAttachment","invalidation"], _f1Weather202320181);
  main.variable(observer()).define(["Inputs","f1Weather202320181"], _3);
  main.variable(observer()).define(["Plot","f1Weather202320181","d3"], _4);
  main.variable(observer()).define(["htl"], _5);
  main.variable(observer()).define(["Plot","d3","f1Weather202320181"], _6);
  main.variable(observer("fields")).define("fields", _fields);
  main.variable(observer("corr")).define("corr", ["d3"], _corr);
  main.variable(observer("correlations")).define("correlations", ["d3","fields","corr","Plot","f1Weather202320181"], _correlations);
  main.variable(observer()).define(["htl"], _10);
  main.variable(observer()).define(["Plot","correlations"], _11);
  main.variable(observer()).define(["htl"], _12);
  return main;
}
